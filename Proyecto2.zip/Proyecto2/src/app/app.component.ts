import { Component } from '@angular/core';
import { TareasComponent } from './tareas/tareas.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [TareasComponent],  // Aquí importas el componente
  templateUrl: './app.component.html',
})
export class AppComponent {
}
