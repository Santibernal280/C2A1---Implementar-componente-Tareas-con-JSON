export class Tarea {
    id: number;
    nomTarea: string;
    descripcion: string;
    fechaCreacion: string;
    responsable: string;
    email: string;
  }
  