import { Component, OnInit } from '@angular/core';
import { Tarea } from './tarea';

@Component({
  selector: 'app-tareas',
  standalone: true,
  imports: [],
  templateUrl: './tareas.component.html',
  styleUrls: ['./tareas.component.css']
})
export class TareasComponent implements OnInit {
  tareas: Tarea[] = [
    {id: 1, nomTarea: 'Caso de Uso 1', descripcion: 'Tarea de Angular', fechaCreacion: '2024-09-08', 
    responsable: 'Julian Quimbayo', email: 'julian.quimbayo@corhuila.edu.co'}
  ];

  ngOnInit(): void {}
}
